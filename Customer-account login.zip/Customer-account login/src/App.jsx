import { Routes, Route, Navigate } from "react-router-dom";
import CustomerSignup from "./pages/CustomerSignup";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/signup" replace />} />
      <Route path="/signup" element={<CustomerSignup />} />

      {/* Add these when ready: */}
      {/* <Route path="/login" element={<CustomerLogin />} /> */}
      {/* <Route path="/terms" element={<Terms />} /> */}
      {/* <Route path="/privacy" element={<Privacy />} /> */}
    </Routes>
  );
}

export default App;
