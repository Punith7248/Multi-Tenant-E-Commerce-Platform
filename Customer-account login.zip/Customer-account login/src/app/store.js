import { configureStore } from "@reduxjs/toolkit";
import signupReducer from "../features/signup/signupSlice";

export const store = configureStore({
  reducer: {
    signup: signupReducer,
    // add loginReducer here later if/when you bring the login page into this project
  },
});
