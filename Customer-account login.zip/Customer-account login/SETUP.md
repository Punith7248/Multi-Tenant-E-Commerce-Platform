# NovaCart Signup — Quick Start (from a downloaded zip)

You downloaded `novacart-app.zip`. Here's the whole process, click by click.

## 1. Unzip it
Find `novacart-app.zip` in your Downloads folder. Right-click it → **Extract All** →
choose a location you'll remember (e.g. Documents) → **Extract**.
You should now have a normal folder called `novacart-app`.

## 2. Open it in VS Code
Open VS Code. Go to **File > Open Folder...** and select the `novacart-app`
folder you just extracted. Click **Select Folder**.

## 3. Open the terminal inside VS Code
Menu bar: **Terminal > New Terminal** (or press `Ctrl + \`` — the backtick
key, top-left of your keyboard under Esc). A terminal panel opens at the
bottom, already inside the `novacart-app` folder.

## 4. Install the dependencies
In that terminal, type this and press Enter:
```bash
npm install
```
This reads `package.json` and downloads everything the project needs
(React, Redux Toolkit, Tailwind, React Router, icons). It'll take a minute
and create a `node_modules` folder — that's normal, don't touch it.

## 5. Run it
```bash
npm run dev
```
It will print something like:
```
Local:   http://localhost:5173/
```
Hold `Ctrl` and click that link (or copy/paste it into your browser). You
should see the Create Customer Account page.

## To stop the server
Click into the terminal and press `Ctrl + C`.

## Where things live (for when you want to change something)
```
novacart-app/
├── package.json          ← dependency list, don't need to touch this
├── index.html             ← the single HTML page Vite serves
├── vite.config.js
├── tailwind.config.js     ← Tailwind's brand colors are defined here
├── postcss.config.js
└── src/
    ├── main.jsx            ← app entry point (Redux + Router wiring)
    ├── App.jsx             ← page routes (currently just /signup)
    ├── index.css           ← Tailwind's base styles
    ├── app/
    │   └── store.js        ← Redux store
    ├── features/
    │   └── signup/
    │       └── signupSlice.js   ← form state (name, email, password, etc.)
    └── pages/
        └── CustomerSignup.jsx   ← the actual page you see in the browser
```

## If something goes wrong
Copy the exact error text from the terminal (or a screenshot) and send it to
me — I'll tell you exactly what to fix.

## Next steps once this is running
1. Point `registerCustomer` in `signupSlice.js` at your real backend.
2. Add stronger validation (email format, password rules).
3. Build the matching `CustomerLogin` page and wire it into `App.jsx`.
