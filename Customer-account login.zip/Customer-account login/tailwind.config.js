/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: "#5744df",
          dark: "#4735c9",
          light: "#f2f0ff",
        },
        ink: "#10102c",
      },
    },
  },
  plugins: [],
};
