# NovaCart - Customer Frontend Contribution

Owner: Frontend Member 1

## Commit these files
Customer login, signup, customer shopping/cart/order dashboard, and customer page assets.

## Do not overwrite
Do not replace `src/main.jsx`, `src/app.css`, `src/api.js`, or `src/store.js` from your branch. The Home/Super Admin member owns the shared routing integration.

## Git
Create a branch such as `feature/customer-frontend`, copy these files into the main project, test, commit, and push.
