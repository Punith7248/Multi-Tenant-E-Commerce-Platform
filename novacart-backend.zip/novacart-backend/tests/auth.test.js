const request = require("supertest");
const mongoose = require("mongoose");
const { MongoMemoryServer } = require("mongodb-memory-server");

let mongod;
let app;

beforeAll(async () => {
  mongod = await MongoMemoryServer.create();
  process.env.MONGO_URI = mongod.getUri();
  process.env.JWT_SECRET = "test_secret";
  process.env.NODE_ENV = "test";
  await mongoose.connect(process.env.MONGO_URI);
  app = require("../src/server");
});

afterAll(async () => {
  await mongoose.disconnect();
  await mongod.stop();
});

describe("Health check", () => {
  it("GET /api/health returns ok", async () => {
    const res = await request(app).get("/api/health");
    expect(res.status).toBe(200);
    expect(res.body.status).toBe("ok");
  });
});

describe("Auth flow", () => {
  const user = {
    fullName: "Jordan Rivera",
    email: "jordan@example.com",
    password: "supersecure1",
    role: "customer",
  };

  it("registers a new user", async () => {
    const res = await request(app).post("/api/auth/register").send(user);
    expect(res.status).toBe(201);
    expect(res.body.data.token).toBeDefined();
    expect(res.body.data.role).toBe("customer");
  });

  it("rejects duplicate email registration", async () => {
    const res = await request(app).post("/api/auth/register").send(user);
    expect(res.status).toBe(400);
  });

  it("logs in with correct credentials", async () => {
    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: user.email, password: user.password });
    expect(res.status).toBe(200);
    expect(res.body.data.token).toBeDefined();
  });

  it("rejects login with wrong password", async () => {
    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: user.email, password: "wrongpassword" });
    expect(res.status).toBe(401);
  });

  it("blocks /api/auth/me without a token", async () => {
    const res = await request(app).get("/api/auth/me");
    expect(res.status).toBe(401);
  });

  it("allows /api/auth/me with a valid token", async () => {
    const login = await request(app)
      .post("/api/auth/login")
      .send({ email: user.email, password: user.password });
    const res = await request(app)
      .get("/api/auth/me")
      .set("Authorization", `Bearer ${login.body.data.token}`);
    expect(res.status).toBe(200);
    expect(res.body.data.email).toBe(user.email);
  });
});
