const express = require("express");
const { getStoreAnalytics, getPlatformAnalytics } = require("../controllers/analyticsController");
const { protect, authorize } = require("../middleware/auth");

const router = express.Router();

router.get("/store", protect, authorize("vendor"), getStoreAnalytics);
router.get("/platform", protect, authorize("admin"), getPlatformAnalytics);

module.exports = router;
