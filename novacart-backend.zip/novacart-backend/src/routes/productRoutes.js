const express = require("express");
const {
  createProduct,
  listProducts,
  getProduct,
  updateProduct,
  deleteProduct,
} = require("../controllers/productController");
const { protect, authorize } = require("../middleware/auth");
const upload = require("../middleware/upload");

const router = express.Router();

router.get("/", listProducts);
router.get("/:id", getProduct);

router.post("/", protect, authorize("vendor"), upload.array("images", 5), createProduct);
router.patch("/:id", protect, authorize("vendor"), upload.array("images", 5), updateProduct);
router.delete("/:id", protect, authorize("vendor"), deleteProduct);

module.exports = router;
