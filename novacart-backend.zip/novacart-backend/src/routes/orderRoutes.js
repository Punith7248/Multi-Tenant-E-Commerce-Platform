const express = require("express");
const {
  createOrder,
  getMyOrders,
  getOrder,
  getStoreOrders,
} = require("../controllers/orderController");
const { protect, authorize } = require("../middleware/auth");

const router = express.Router();

router.post("/", protect, authorize("customer"), createOrder);
router.get("/me", protect, authorize("customer"), getMyOrders);
router.get("/store", protect, authorize("vendor"), getStoreOrders);
router.get("/:id", protect, getOrder);

module.exports = router;
