const express = require("express");
const { createPaymentIntent } = require("../controllers/paymentController");
const { protect, authorize } = require("../middleware/auth");

const router = express.Router();

router.post("/create-intent", protect, authorize("customer"), createPaymentIntent);

module.exports = router;
