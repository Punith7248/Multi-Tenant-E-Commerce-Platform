const express = require("express");
const {
  createStore,
  getStore,
  getMyStore,
  updateMyStore,
} = require("../controllers/storeController");
const { protect, authorize } = require("../middleware/auth");

const router = express.Router();

router.get("/me", protect, authorize("vendor"), getMyStore);
router.patch("/me", protect, authorize("vendor"), updateMyStore);
router.post("/", protect, authorize("vendor"), createStore);
router.get("/:idOrSlug", getStore);

module.exports = router;
