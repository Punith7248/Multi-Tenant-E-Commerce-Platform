const express = require("express");
const { handleStripeWebhook } = require("../controllers/paymentController");

const router = express.Router();

// Stripe requires the raw body to verify the signature — this route is mounted
// BEFORE express.json() in server.js for that reason.
router.post("/stripe", express.raw({ type: "application/json" }), handleStripeWebhook);

module.exports = router;
