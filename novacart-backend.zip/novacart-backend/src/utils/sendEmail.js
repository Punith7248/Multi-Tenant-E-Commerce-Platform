const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT) || 587,
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

async function sendEmail({ to, subject, html, text }) {
  await transporter.sendMail({
    from: process.env.EMAIL_FROM,
    to,
    subject,
    html,
    text,
  });
}

function orderConfirmationTemplate(order) {
  const itemRows = order.items
    .map(
      (i) =>
        `<tr><td>${i.name}</td><td>${i.quantity}</td><td>$${i.price.toFixed(2)}</td></tr>`
    )
    .join("");

  return `
    <h2>Thanks for your order!</h2>
    <p>Order ID: ${order._id}</p>
    <table border="1" cellpadding="8" cellspacing="0">
      <thead><tr><th>Item</th><th>Qty</th><th>Price</th></tr></thead>
      <tbody>${itemRows}</tbody>
    </table>
    <p><strong>Total: $${order.totalAmount.toFixed(2)}</strong></p>
  `;
}

module.exports = { sendEmail, orderConfirmationTemplate };
