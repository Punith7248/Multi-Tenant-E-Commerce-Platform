const asyncHandler = require("express-async-handler");
const Store = require("../models/Store");
const User = require("../models/User");

function slugify(name) {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

// @route  POST /api/stores
// @access Private (vendor)
const createStore = asyncHandler(async (req, res) => {
  const { name, description, contactEmail } = req.body;

  if (!name) {
    res.status(400);
    throw new Error("Store name is required");
  }

  const existing = await Store.findOne({ owner: req.user._id });
  if (existing) {
    res.status(400);
    throw new Error("This vendor already has a store");
  }

  let slug = slugify(name);
  const slugTaken = await Store.findOne({ slug });
  if (slugTaken) slug = `${slug}-${Date.now().toString(36)}`;

  const store = await Store.create({
    owner: req.user._id,
    name,
    slug,
    description,
    contactEmail: contactEmail || req.user.email,
  });

  await User.findByIdAndUpdate(req.user._id, { store: store._id });

  res.status(201).json({ success: true, data: store });
});

// @route  GET /api/stores/:idOrSlug
// @access Public
const getStore = asyncHandler(async (req, res) => {
  const { idOrSlug } = req.params;
  const query = idOrSlug.match(/^[0-9a-fA-F]{24}$/)
    ? { _id: idOrSlug }
    : { slug: idOrSlug };

  const store = await Store.findOne({ ...query, isActive: true });
  if (!store) {
    res.status(404);
    throw new Error("Store not found");
  }
  res.json({ success: true, data: store });
});

// @route  GET /api/stores/me
// @access Private (vendor)
const getMyStore = asyncHandler(async (req, res) => {
  const store = await Store.findOne({ owner: req.user._id });
  if (!store) {
    res.status(404);
    throw new Error("You don't have a store yet");
  }
  res.json({ success: true, data: store });
});

// @route  PATCH /api/stores/me
// @access Private (vendor, owner only)
const updateMyStore = asyncHandler(async (req, res) => {
  const store = await Store.findOne({ owner: req.user._id });
  if (!store) {
    res.status(404);
    throw new Error("You don't have a store yet");
  }

  const updatable = ["name", "description", "logoUrl", "bannerUrl", "contactEmail"];
  updatable.forEach((field) => {
    if (req.body[field] !== undefined) store[field] = req.body[field];
  });

  await store.save();
  res.json({ success: true, data: store });
});

module.exports = { createStore, getStore, getMyStore, updateMyStore };
