const asyncHandler = require("express-async-handler");
const mongoose = require("mongoose");
const Order = require("../models/Order");
const Product = require("../models/Product");

// @route  POST /api/orders
// @access Private (customer)
// body: { items: [{ product, quantity }], shippingAddress }
const createOrder = asyncHandler(async (req, res) => {
  const { items, shippingAddress } = req.body;

  if (!Array.isArray(items) || items.length === 0) {
    res.status(400);
    throw new Error("Order must contain at least one item");
  }

  const productIds = items.map((i) => i.product);
  const products = await Product.find({ _id: { $in: productIds }, isActive: true });

  if (products.length !== productIds.length) {
    res.status(400);
    throw new Error("One or more products are unavailable");
  }

  const orderItems = items.map((i) => {
    const product = products.find((p) => p._id.toString() === i.product);
    if (product.stock < i.quantity) {
      const err = new Error(`Insufficient stock for ${product.name}`);
      err.statusCode = 400;
      throw err;
    }
    return {
      product: product._id,
      store: product.store,
      name: product.name,
      price: product.price,
      quantity: i.quantity,
    };
  });

  const totalAmount = orderItems.reduce((sum, i) => sum + i.price * i.quantity, 0);

  const session = await mongoose.startSession();
  let order;
  try {
    await session.withTransaction(async () => {
      // decrement stock atomically
      for (const item of orderItems) {
        await Product.updateOne(
          { _id: item.product },
          { $inc: { stock: -item.quantity } },
          { session }
        );
      }

      order = await Order.create(
        [
          {
            customer: req.user._id,
            items: orderItems,
            totalAmount,
            shippingAddress,
            status: "pending",
          },
        ],
        { session }
      );
    });
  } finally {
    session.endSession();
  }

  res.status(201).json({ success: true, data: order[0] });
});

// @route  GET /api/orders/me
// @access Private (customer)
const getMyOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find({ customer: req.user._id }).sort({ createdAt: -1 });
  res.json({ success: true, data: orders });
});

// @route  GET /api/orders/:id
// @access Private (owner customer, or vendor whose store is in the order, or admin)
const getOrder = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order) {
    res.status(404);
    throw new Error("Order not found");
  }

  const isOwner = order.customer.toString() === req.user._id.toString();
  const isVendorForOrder =
    req.user.role === "vendor" &&
    order.items.some((i) => i.store.toString() === req.user.store?.toString());

  if (!isOwner && !isVendorForOrder && req.user.role !== "admin") {
    res.status(403);
    throw new Error("Not authorized to view this order");
  }

  res.json({ success: true, data: order });
});

// @route  GET /api/orders/store  (vendor's orders — items belonging to their store)
// @access Private (vendor)
const getStoreOrders = asyncHandler(async (req, res) => {
  if (!req.user.store) {
    res.status(400);
    throw new Error("You don't have a store yet");
  }

  const orders = await Order.find({ "items.store": req.user.store }).sort({
    createdAt: -1,
  });
  res.json({ success: true, data: orders });
});

module.exports = { createOrder, getMyOrders, getOrder, getStoreOrders };
