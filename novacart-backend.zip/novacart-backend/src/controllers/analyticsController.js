const asyncHandler = require("express-async-handler");
const mongoose = require("mongoose");
const Order = require("../models/Order");

// @route  GET /api/analytics/store  (vendor's own store)
// @access Private (vendor)
// query: ?from=YYYY-MM-DD&to=YYYY-MM-DD
const getStoreAnalytics = asyncHandler(async (req, res) => {
  if (!req.user.store) {
    res.status(400);
    throw new Error("You don't have a store yet");
  }

  const storeId = new mongoose.Types.ObjectId(req.user.store);
  const from = req.query.from ? new Date(req.query.from) : new Date(0);
  const to = req.query.to ? new Date(req.query.to) : new Date();

  const [summary] = await Order.aggregate([
    { $match: { status: { $in: ["paid", "processing", "shipped", "delivered"] } } },
    { $unwind: "$items" },
    { $match: { "items.store": storeId, createdAt: { $gte: from, $lte: to } } },
    {
      $group: {
        _id: null,
        revenue: { $sum: { $multiply: ["$items.price", "$items.quantity"] } },
        unitsSold: { $sum: "$items.quantity" },
        orderIds: { $addToSet: "$_id" },
      },
    },
    {
      $project: {
        _id: 0,
        revenue: 1,
        unitsSold: 1,
        orderCount: { $size: "$orderIds" },
      },
    },
  ]);

  const dailyRevenue = await Order.aggregate([
    { $match: { status: { $in: ["paid", "processing", "shipped", "delivered"] } } },
    { $unwind: "$items" },
    { $match: { "items.store": storeId, createdAt: { $gte: from, $lte: to } } },
    {
      $group: {
        _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
        revenue: { $sum: { $multiply: ["$items.price", "$items.quantity"] } },
      },
    },
    { $sort: { _id: 1 } },
  ]);

  res.json({
    success: true,
    data: {
      summary: summary || { revenue: 0, unitsSold: 0, orderCount: 0 },
      dailyRevenue,
    },
  });
});

// @route  GET /api/analytics/platform  (admin only)
// @access Private (admin)
const getPlatformAnalytics = asyncHandler(async (req, res) => {
  const [result] = await Order.aggregate([
    { $match: { status: { $in: ["paid", "processing", "shipped", "delivered"] } } },
    {
      $group: {
        _id: null,
        totalRevenue: { $sum: "$totalAmount" },
        totalOrders: { $sum: 1 },
      },
    },
  ]);

  const ordersByStatus = await Order.aggregate([
    { $group: { _id: "$status", count: { $sum: 1 } } },
  ]);

  res.json({
    success: true,
    data: {
      totalRevenue: result?.totalRevenue || 0,
      totalOrders: result?.totalOrders || 0,
      ordersByStatus,
    },
  });
});

module.exports = { getStoreAnalytics, getPlatformAnalytics };
