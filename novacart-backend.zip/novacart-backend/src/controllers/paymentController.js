const asyncHandler = require("express-async-handler");
const Stripe = require("stripe");
const Order = require("../models/Order");
const Product = require("../models/Product");
const { sendEmail, orderConfirmationTemplate } = require("../utils/sendEmail");

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

// @route  POST /api/payments/create-intent
// @access Private (customer)
// body: { orderId }
const createPaymentIntent = asyncHandler(async (req, res) => {
  const { orderId } = req.body;

  const order = await Order.findOne({ _id: orderId, customer: req.user._id });
  if (!order) {
    res.status(404);
    throw new Error("Order not found");
  }
  if (order.paymentStatus === "paid") {
    res.status(400);
    throw new Error("Order is already paid");
  }

  const paymentIntent = await stripe.paymentIntents.create({
    amount: Math.round(order.totalAmount * 100), // Stripe expects cents
    currency: "usd",
    metadata: { orderId: order._id.toString(), customerId: req.user._id.toString() },
    automatic_payment_methods: { enabled: true },
  });

  order.paymentIntentId = paymentIntent.id;
  await order.save();

  res.json({ success: true, data: { clientSecret: paymentIntent.client_secret } });
});

// Called from the raw-body Stripe webhook route (see routes/webhookRoutes.js)
const handleStripeWebhook = async (req, res) => {
  const sig = req.headers["stripe-signature"];
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error(`Webhook signature verification failed: ${err.message}`);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  switch (event.type) {
    case "payment_intent.succeeded": {
      const intent = event.data.object;
      const order = await Order.findOne({ paymentIntentId: intent.id }).populate("customer");
      if (order) {
        order.status = "paid";
        order.paymentStatus = "paid";
        await order.save();

        // Nodemailer confirmation email (W3-D7)
        if (order.customer?.email) {
          sendEmail({
            to: order.customer.email,
            subject: "Your NovaCart order is confirmed",
            html: orderConfirmationTemplate(order),
          }).catch((err) => console.error("Order email failed:", err.message));
        }
      }
      break;
    }
    case "payment_intent.payment_failed": {
      const intent = event.data.object;
      const order = await Order.findOne({ paymentIntentId: intent.id });
      if (order) {
        order.status = "failed";
        await order.save();

        // Restock items since payment failed
        await Promise.all(
          order.items.map((i) =>
            Product.updateOne({ _id: i.product }, { $inc: { stock: i.quantity } })
          )
        );
      }
      break;
    }
    default:
      break; // ignore other event types
  }

  res.json({ received: true });
};

module.exports = { createPaymentIntent, handleStripeWebhook };
