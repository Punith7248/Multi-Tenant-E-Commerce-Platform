const asyncHandler = require("express-async-handler");
const Product = require("../models/Product");
const Store = require("../models/Store");
const cloudinary = require("../config/cloudinary");

async function getOwnedStoreOrFail(userId) {
  const store = await Store.findOne({ owner: userId });
  if (!store) {
    const err = new Error("You don't have a store yet — create one first");
    err.statusCode = 400;
    throw err;
  }
  return store;
}

// @route  POST /api/products
// @access Private (vendor)
const createProduct = asyncHandler(async (req, res) => {
  const store = await getOwnedStoreOrFail(req.user._id);
  const { name, description, price, stock, category } = req.body;

  if (!name || price === undefined) {
    res.status(400);
    throw new Error("name and price are required");
  }

  // req.files populated by the Cloudinary/Multer middleware (W2-D3)
  const images = (req.files || []).map((f) => ({
    url: f.path,
    publicId: f.filename,
  }));

  const product = await Product.create({
    store: store._id,
    name,
    description,
    price,
    stock: stock || 0,
    category,
    images,
  });

  res.status(201).json({ success: true, data: product });
});

// @route  GET /api/products
// @access Public
// Supports ?store=<id>&category=<cat>&q=<search>&page=&limit=
const listProducts = asyncHandler(async (req, res) => {
  const { store, category, q, page = 1, limit = 20 } = req.query;
  const filter = { isActive: true };

  if (store) filter.store = store;
  if (category) filter.category = category;
  if (q) filter.$text = { $search: q };

  const skip = (Number(page) - 1) * Number(limit);

  const [products, total] = await Promise.all([
    Product.find(filter).skip(skip).limit(Number(limit)).sort({ createdAt: -1 }),
    Product.countDocuments(filter),
  ]);

  res.json({
    success: true,
    data: products,
    pagination: { total, page: Number(page), pages: Math.ceil(total / limit) },
  });
});

// @route  GET /api/products/:id
// @access Public
const getProduct = asyncHandler(async (req, res) => {
  const product = await Product.findOne({ _id: req.params.id, isActive: true }).populate(
    "store",
    "name slug"
  );
  if (!product) {
    res.status(404);
    throw new Error("Product not found");
  }
  res.json({ success: true, data: product });
});

// @route  PATCH /api/products/:id
// @access Private (vendor, owner of the product's store)
const updateProduct = asyncHandler(async (req, res) => {
  const store = await getOwnedStoreOrFail(req.user._id);
  const product = await Product.findOne({ _id: req.params.id, store: store._id });

  if (!product) {
    res.status(404);
    throw new Error("Product not found in your store");
  }

  const updatable = ["name", "description", "price", "stock", "category", "isActive"];
  updatable.forEach((field) => {
    if (req.body[field] !== undefined) product[field] = req.body[field];
  });

  if (req.files && req.files.length > 0) {
    const newImages = req.files.map((f) => ({ url: f.path, publicId: f.filename }));
    product.images.push(...newImages);
  }

  await product.save();
  res.json({ success: true, data: product });
});

// @route  DELETE /api/products/:id
// @access Private (vendor, owner of the product's store)
const deleteProduct = asyncHandler(async (req, res) => {
  const store = await getOwnedStoreOrFail(req.user._id);
  const product = await Product.findOne({ _id: req.params.id, store: store._id });

  if (!product) {
    res.status(404);
    throw new Error("Product not found in your store");
  }

  // Clean up Cloudinary assets (W2-D3)
  await Promise.all(
    product.images.map((img) =>
      cloudinary.uploader.destroy(img.publicId).catch(() => null)
    )
  );

  await product.deleteOne();
  res.json({ success: true, message: "Product deleted" });
});

module.exports = { createProduct, listProducts, getProduct, updateProduct, deleteProduct };
