# NovaCart Backend

Multi-tenant e-commerce backend — Node.js/Express, MongoDB/Mongoose, JWT auth,
Stripe, Cloudinary, Nodemailer — built against the "Backend Task Plan"
(Weeks 1–4, 23 tasks).

This is a working implementation, not a scaffold: models, auth/RBAC, Store
and Product CRUD, image uploads, payments + webhook, orders, and analytics
are all wired together and syntax-checked. Sandbox networking is disabled
here so `npm install` couldn't be run in this environment — run it locally
before starting the server (see below), and the included Jest suite will
tell you immediately if anything's off.

## Setup

```bash
npm install
cp .env.example .env   # fill in MONGO_URI, JWT_SECRET, Cloudinary/Stripe/SMTP keys
npm run dev             # nodemon, http://localhost:5000
```

Run the smoke tests (spins up an in-memory MongoDB, no Atlas needed):

```bash
npm test
```

## Project layout

```
src/
  config/       Mongo + Cloudinary setup
  models/       User, Store, Product, Order (Mongoose)
  middleware/   JWT auth + RBAC, Multer/Cloudinary upload, error handler
  controllers/  business logic per resource
  routes/       Express routers
  utils/        JWT signing, Nodemailer + email template
  server.js     app bootstrap: middleware, routes, error handling
tests/
  auth.test.js  register/login/me smoke test
```

## Task plan → code map

| Task | Where |
|---|---|
| W1-D1 folder structure & conventions | this layout — config/models/middleware/controllers/routes/utils |
| W1-D2 Mongoose schemas | `src/models/*.js` |
| W1-D3 Express + Helmet/CORS/health | `src/server.js` |
| W1-D4 Register/Login + Bcrypt | `src/controllers/authController.js`, `models/User.js` |
| W1-D5 JWT + RBAC | `src/middleware/auth.js` |
| W2-D1 Store CRUD | `src/controllers/storeController.js` |
| W2-D2 Product CRUD (per-store) | `src/controllers/productController.js` |
| W2-D3 Cloudinary + Multer | `src/middleware/upload.js` |
| W3-D3 Stripe Payment Intent | `src/controllers/paymentController.js` → `createPaymentIntent` |
| W3-D5 Stripe webhook | `src/routes/webhookRoutes.js` + `handleStripeWebhook` |
| W3-D6 Order model + create-order | `src/models/Order.js`, `controllers/orderController.js` |
| W3-D7 Nodemailer confirmation | `src/utils/sendEmail.js`, fired from the webhook on `payment_intent.succeeded` |
| W4-D1 Analytics aggregation | `src/controllers/analyticsController.js` |
| W4-D4 Test cases | `tests/auth.test.js` |
| W4-D5 Indexing / security review | see "Notes" below |
| W4-D6 CI/CD | not included — see "Not included" |
| W4-D7 Deploy | not included — see "Not included" |

## API reference

**Auth**
- `POST /api/auth/register` — `{ fullName, email, password, phone?, role? }` → token
- `POST /api/auth/login` — `{ email, password }` → token
- `GET /api/auth/me` — 🔒 current user

**Stores**
- `POST /api/stores` — 🔒 vendor, creates the caller's store
- `GET /api/stores/me` — 🔒 vendor
- `PATCH /api/stores/me` — 🔒 vendor
- `GET /api/stores/:idOrSlug` — public

**Products**
- `GET /api/products?store=&category=&q=&page=&limit=` — public
- `GET /api/products/:id` — public
- `POST /api/products` — 🔒 vendor, multipart `images` field (up to 5)
- `PATCH /api/products/:id` — 🔒 vendor (owner)
- `DELETE /api/products/:id` — 🔒 vendor (owner), also removes Cloudinary assets

**Orders**
- `POST /api/orders` — 🔒 customer, `{ items: [{product, quantity}], shippingAddress }`; decrements stock in a transaction
- `GET /api/orders/me` — 🔒 customer
- `GET /api/orders/store` — 🔒 vendor, orders containing their store's items
- `GET /api/orders/:id` — 🔒 owner customer / relevant vendor / admin

**Payments**
- `POST /api/payments/create-intent` — 🔒 customer, `{ orderId }` → Stripe `clientSecret`
- `POST /api/webhooks/stripe` — Stripe → marks order paid/failed, restocks on failure, sends confirmation email

**Analytics**
- `GET /api/analytics/store?from=&to=` — 🔒 vendor, revenue/units/orders + daily revenue
- `GET /api/analytics/platform` — 🔒 admin, platform-wide totals

## Notes (W4-D5)

- Indexes are declared on the schemas that need them: `Product` (text search
  on name/description, `store` and `category`), `Order` (`customer`,
  `status`, `paymentIntentId`), `Store` (`slug` unique, text search). Run
  `db.collection.getIndexes()` in Atlas after your first deploy to confirm
  they built.
- Stock decrement on order creation uses a Mongo transaction, so a failed
  order never leaves stock in a half-updated state — Atlas free tier
  supports transactions on a replica set, which Atlas gives you by default.
- Passwords are hashed with bcrypt (10 rounds) and never returned from
  queries (`select: false` on the field). JWT secret and all third-party
  keys are read from `.env` only — nothing is hardcoded.
- Helmet + a 300-req/15-min rate limiter are applied globally; tighten the
  limiter for `/api/auth` specifically if you see brute-force attempts.

## Not included (out of scope here)

- **W4-D6 CI/CD** and **W4-D7 deploy** are environment/infra steps (GitHub
  Actions YAML, Render/AWS setup) rather than application code — happy to
  add a `.github/workflows/ci.yml` if you want a starting point.
- Frontend integration: this pairs with the React frontend built earlier —
  the two "already have an account" flows call `POST /api/auth/login` and
  `POST /api/auth/register` respectively.
- Password reset, OAuth (Google/Apple), email verification, and vendor
  signup were flagged as gaps against the mockups earlier — not built yet
  since they weren't in the 23-task plan. Say the word if you want any of
  them added.
