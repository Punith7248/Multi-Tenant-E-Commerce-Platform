/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#f2f0ff",
          100: "#e6e3ff",
          200: "#c9c2ff",
          300: "#a89bff",
          400: "#8672ff",
          500: "#6c4ef5",
          600: "#5b3ce0",
          700: "#4a2fc0",
          800: "#3c2799",
          900: "#2e1f75",
        },
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
}
