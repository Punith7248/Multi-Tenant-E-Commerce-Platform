import { Link } from "react-router-dom";
import BrandPanel from "../components/BrandPanel";

export default function CreateAccount() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4 sm:p-8">
      <div className="flex w-full max-w-5xl overflow-hidden rounded-2xl bg-white shadow-xl">
        <BrandPanel
          heading="For People Who Love Great Choices."
          subheading="Shop from thousands of independent stores in one place."
          // footer="Every purchase
          //  supports a bigger dream."
          footer={`Every purchase
supports a bigger dream.`}
        />

        <div className="flex flex-1 flex-col justify-center px-6 py-10 sm:px-10 lg:px-14">
          <div className="mx-auto w-full max-w-sm">
            <div className="flex items-center gap-2 mb-10">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-500 text-white">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M6 8h12l1 13H5L6 8Z" />
                  <path d="M9 8V6a3 3 0 0 1 6 0v2" />
                </svg>
              </span>
              <span className="text-lg font-bold text-gray-900">NovaCart</span>
            </div>

            <h2 className="text-2xl font-bold text-gray-900">Create your account</h2>
            <p className="mt-1 text-sm text-gray-500">
              This is a placeholder page — wire it up the same way as Login.
            </p>

            <div className="mt-8 rounded-lg border border-dashed border-gray-300 p-6 text-sm text-gray-500">
              Add your signup form fields here (name, email, password, etc.),
              following the same pattern used in <code>Login.jsx</code>.
            </div>

            <p className="mt-6 text-sm text-gray-500">
              Already have an account?{" "}
              <Link to="/login" className="font-medium text-brand-600 hover:text-brand-700">
                Log in
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
