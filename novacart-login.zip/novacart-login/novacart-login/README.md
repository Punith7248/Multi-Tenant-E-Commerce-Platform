# NovaCart – Customer Login (Frontend Only)

Stack: **React.js + Redux Toolkit + Tailwind CSS + React Router DOM**, built with Vite.

## What's inside

```
novacart-login/
├── index.html
├── package.json
├── tailwind.config.js
├── postcss.config.js
├── vite.config.js
└── src/
    ├── main.jsx            # Redux <Provider> + <BrowserRouter> setup
    ├── App.jsx             # Route definitions
    ├── index.css           # Tailwind directives
    ├── store/
    │   ├── store.js        # Redux store
    │   └── authSlice.js    # Login form state + fake auth flow
    ├── components/
    │   └── BrandPanel.jsx  # Left-side image panel (reused on Login & Create Account)
    ├── pages/
    │   ├── Login.jsx       # Matches your reference screenshot
    │   ├── CreateAccount.jsx
    │   └── Dashboard.jsx   # Shown after a successful "login"
    └── assets/
        └── background.jpeg # Your uploaded image, used as the panel background
```

## How to run it (step by step, assuming zero setup)

1. **Install Node.js** if you don't have it: https://nodejs.org (LTS version). This gives you `node` and `npm`.
2. **Unzip this folder** and open a terminal inside it (`cd novacart-login`).
3. **Install dependencies:**
   ```bash
   npm install
   ```
4. **Start the dev server:**
   ```bash
   npm run dev
   ```
5. Open the URL it prints (usually `http://localhost:5173`) in your browser. You'll land on `/login`.

## How the pieces fit together

- **React Router DOM** (`App.jsx`) defines three pages: `/login`, `/create-account`, `/dashboard`, and redirects anything else back to `/login`.
- **Redux Toolkit** (`store/authSlice.js`) holds the login form's state: email, password, "remember me", show/hide password, and a fake `loading → succeeded/failed` login flow. Components read this with `useSelector` and update it with `dispatch(...)`.
- **Tailwind CSS** does all the styling — no separate CSS files per component, just utility classes in the JSX.
- **BrandPanel.jsx** is the reusable purple/photo panel on the left. It uses `src/assets/background.jpeg` (the second image you sent) as a `background-image`, with a dark overlay so the white text stays readable.

## Next steps you'll likely want

- Swap the `setTimeout` fake login in `Login.jsx` with a real API call (e.g. `fetch('/api/login', ...)`), and dispatch `loginSuccess`/`loginFailure` based on the response.
- Fill in real fields on `CreateAccount.jsx` (it's currently a placeholder using the same layout).
- Add real Google/Apple icons (currently emoji placeholders) — e.g. from `react-icons`.
- Add form validation (e.g. `react-hook-form` or simple regex checks) before dispatching.
